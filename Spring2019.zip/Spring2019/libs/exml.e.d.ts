declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class btn_close extends eui.Skin{
}
declare class btn_return extends eui.Skin{
}
declare class golden_coin extends eui.Skin{
}
declare class goods_item extends eui.Skin{
}
declare class records_item extends eui.Skin{
}
declare class scores extends eui.Skin{
}
declare class LoadingMeSkin extends eui.Skin{
}
declare class MainSceneSkin extends eui.Skin{
}
declare class PlaySceneSkin extends eui.Skin{
}
declare class RankSceneSkin extends eui.Skin{
}
declare class RecordSceneSkin extends eui.Skin{
}
declare class RuleSceneSkin extends eui.Skin{
}
declare class StoreSceneSkin extends eui.Skin{
}
