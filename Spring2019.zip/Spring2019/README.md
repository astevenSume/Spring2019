一、LoadingUI.ts 初始化数据库
一、 localStorage值说明状态
    1  用户id

        uid  
        re_uname 为空时正常游戏，非空提示请合租re_uname帐户进行游戏， 即同真实姓名或同身份证不能玩

    2  状态  用来刚进页面时是否显示某个提示 

        main_status   主页状态   
        buy_type 主页的购买类型  
        store_status  商店状态
           

    3  道具数量
        revive_num      复活数量
        clean_num       净化药水数量
        shield_num      护盾数量
        double_num      双倍数量
        speed_num       缓速数量

    4, 
        current_tiems  当前用户今天玩几局了
